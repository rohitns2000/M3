package com.cg.dao;

import java.util.List;

import com.cg.entities.Trainee;

public interface traineeDAO {
	public List<Trainee> getAllTrainee();
	public boolean addTrainee(Trainee tr);
	public void deleteTrainee(Integer tr);
	public void modify(Trainee t);
	public Trainee find(int id);
}
