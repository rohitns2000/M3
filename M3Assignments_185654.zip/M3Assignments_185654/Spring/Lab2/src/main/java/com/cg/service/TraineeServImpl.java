package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.traineeDAO;
import com.cg.dao.traineeDAOImpl;
import com.cg.entities.Trainee;

@Service
@Transactional
public class TraineeServImpl implements TraineeServ{
	@Autowired private traineeDAO dao;
	
	@Transactional(readOnly=true)
	public List<Trainee> getAllTrainee() {
		return dao.getAllTrainee();
	}
	
	@Transactional(readOnly=true)
	public Trainee getTrainee(int id) {
//		List<Trainee> lst = dao.getAllTrainee();
//		for(Trainee tr : lst)
//		{
//			if(id == tr.getTraineeId())
//			{
//				return tr;
//			}
//		}
//		return null;
		return dao.find(id);
	}

	@Transactional(readOnly=true)
	public boolean addTrainee(Trainee tr) {
		// TODO Auto-generated method stub
		return dao.addTrainee(tr);
	}

	public void deleteTrainee(Integer tr) {
		dao.deleteTrainee(tr);
	}

	public void modify(Trainee t) {
		dao.modify(t);
		
	}

}
