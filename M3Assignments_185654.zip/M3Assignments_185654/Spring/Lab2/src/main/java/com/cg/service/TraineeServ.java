package com.cg.service;

import java.util.List;

import com.cg.entities.Trainee;

public interface TraineeServ {
	public List<Trainee> getAllTrainee();
	public Trainee getTrainee(int id);
	public boolean addTrainee(Trainee tr);
	public void deleteTrainee(Integer tr);
	public void modify(Trainee t);
}
