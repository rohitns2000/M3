package com.cg.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Trainee;
import com.cg.service.TraineeServ;
import com.cg.service.TraineeServImpl;

import sun.print.resources.serviceui;

@Controller
public class TraineeController {
	
	
 @Autowired private TraineeServ service;

	@GetMapping("/")
	public String showIndex(Model model) {
		return "login";
	}
	
	@GetMapping("/add")
	public String showAdd(Model model) {
		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		return "add";
	}
	
	@GetMapping("/delete")
	public String showDelete(Model model) {
		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		return "delete";
	}
	
	@GetMapping("/modify")
	public String showModify(Model model) {
		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		return "modify";
	}
	
	@GetMapping("/retrieve")
	public String showRetrieve(Model model) {
		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		return "retrieve";
	}
	
	@GetMapping("/retrieveall")
	public String showRetrieveAll(Model model) {
		Trainee t=new Trainee();
		model.addAttribute("trainee",t);
		List<Trainee> lst = service.getAllTrainee();
		for(Trainee tr1 : lst)
		{
			System.out.println(tr1.getTraineeId()+" "+tr1.getTraineeName()+" "+tr1.getTraineeDomain()+" "+tr1.getTraineeLocation());
		}
		model.addAttribute("lst",lst);
		return "retrieveall";
	}
	
	
	@PostMapping(value="/addtrainee")
	public String addtrainee(Model model,@ModelAttribute("trainee") Trainee tr)
	{
		model.addAttribute("msg1","Trainee added");
		System.out.println("Trainee Added!");
		service.addTrainee(tr);
		return "index";
	}
	
	@PostMapping("/retrieve")
	public String submitRetrieve(@Valid @ModelAttribute("trainee") Trainee tr,BindingResult results,Model model)
	{
		Trainee tr1 = service.getTrainee(tr.getTraineeId());
		
		model.addAttribute("trId",tr1.getTraineeId());
		model.addAttribute("trName",tr1.getTraineeName());
		model.addAttribute("trDomain",tr1.getTraineeDomain());
		model.addAttribute("trLocation",tr1.getTraineeLocation());
		System.out.println("Trainee Retrieved!");
		
		return "retrieve";
	}
	
	@PostMapping("/delete")
	public String submitDelete(@Valid @ModelAttribute("trainee") Trainee tr,BindingResult results,Model model)
	{
		Trainee tr1 = service.getTrainee(tr.getTraineeId());
		
		model.addAttribute("trId",tr1.getTraineeId());
		model.addAttribute("trName",tr1.getTraineeName());
		model.addAttribute("trDomain",tr1.getTraineeDomain());
		model.addAttribute("trLocation",tr1.getTraineeLocation());		
		
		service.deleteTrainee(tr1.getTraineeId());
		System.out.println("Trainee Deleted!");

		return "delete";
	}
	
	@PostMapping("/modify")
	public String submitModify(@Valid @ModelAttribute("trainee") Trainee tr,BindingResult results,Model model)
	{
		Trainee tr1 = service.getTrainee(tr.getTraineeId());
		
		model.addAttribute("trainee",tr1);
		
		Trainee tr2 = new Trainee();
		tr2.setTraineeId(tr.getTraineeId());
		tr2.setTraineeDomain(tr.getTraineeDomain());
		tr2.setTraineeLocation(tr.getTraineeLocation());
		tr2.setTraineeName(tr.getTraineeName());
		System.out.println("Trainee Modified!");
	
		return "modify";
	}
	
	@PostMapping("/modifyfin")
	public String submitModifyfin(@Valid @ModelAttribute("trainee") Trainee tr,BindingResult results,Model model)
	{
		service.modify(tr);
		model.addAttribute("msg1","Trainee Updated");

		return "index";
	}
	
	@PostMapping("/login")
	public String submitLogin(@RequestParam("u") String user, @RequestParam("p") String pass)
	{
		if(user.equals("admin") && pass.equals("admin"))
		{
			System.out.println("Authenticated!");
			return "index";
		}
		return "login";
		
	}
	
	
	
}