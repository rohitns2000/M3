package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;

@Repository
public class traineeDAOImpl implements traineeDAO{
	

	@PersistenceContext
	private EntityManager em;
	
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		Query q = em.createQuery("from Trainee t");
		return q.getResultList();
		
	}

	public boolean addTrainee(Trainee tr) {
		em.persist(tr);
		em.flush();
		return true;
	}

	public void deleteTrainee(Integer tr) {
		Trainee t1 = em.find(Trainee.class, tr);
		em.remove(t1);
	}

	public void modify(Trainee t) {
		em.merge(t);
		
	}

	public Trainee find(int id) {
		// TODO Auto-generated method stub
		return em.find(Trainee.class, id);
	}
	
	

}
