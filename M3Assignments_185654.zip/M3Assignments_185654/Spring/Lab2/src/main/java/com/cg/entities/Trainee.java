package com.cg.entities;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="trainee")
public class Trainee {
	
	@Id
	@NotNull
	@Max(value=10000,message="Trainee ID Cannot be greater than 10000")
	private int traineeId;
	
	@Column(name="traineeName",length=20)
	@NotEmpty(message="Name cannot be empty!")
	private String traineeName;
	
	@Column(name="traineeLocation",length=20)
	@NotEmpty(message="Name cannot be empty!")
	private String traineeLocation;
	
	@Column(name="traineeDomain",length=20)
	@NotEmpty(message="Name cannot be empty!")
	private String traineeDomain;
	
	public Trainee(int traineeId, String traineeName, String traineeLocation, String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;
	}
	public Trainee() {
		super();
	}
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	
	

}
